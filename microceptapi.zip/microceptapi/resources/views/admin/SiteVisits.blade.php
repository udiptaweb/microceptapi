@extends('layouts.app')
@section('content')
 <div class="row">
	<div class="col-lg-4">
		<div class="bs-component">
		  <div class="card text-white bg-primary mb-3" style="max-width: 20rem;">
		    <div class="card-header">Microcept Visits</div>
		    <div class="card-body">
		      <h4 class="card-title">Total</h4>
		      <p class="card-text">{{$sitevisits->count()}}</p>
		    </div>
		  </div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-lg-12">
		<div class="bs-component">
				<h5>Recent Visits</h5>
		    <table class="table table-hover">
			  <thead>
			    <tr>
			      <th scope="col">Domain</th>
			      <th scope="col">Date</th>
			    </tr>
			  </thead>
			  <tbody>
			  	@foreach($sitevisits as $visit)
			    <tr>
			      <td>{{$visit->domain}}</td>
			      <td>{{$visit->created_at}}</td>
			    </tr>
			    @endforeach
			  </tbody>
			</table> 
		</div>
	</div>
</div>
@endsection
