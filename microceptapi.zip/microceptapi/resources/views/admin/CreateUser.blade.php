@extends('layouts.app')
@section('content')
<div class="row">
	<div class="col-lg-6">
		<div class="bs-component">
		    <form action="/api/users/create" method="POST">
			    <fieldset>
			      <legend>CREATE NEW USER</legend>
			       <div class="form-group">
			        <label for="">Name</label>
			        <input type="text" class="form-control form-control-sm"  placeholder="Enter NAME" name="name">
			        
			      </div>
			      <div class="form-group">
			        <label for="">Phone</label>
			        <input type="text" class="form-control form-control-sm" placeholder="Enter Phone" name="phone">
			        
			      </div>
			      <div class="form-group">
			        <label for="exampleInputEmail1">Email address</label>
			        <input type="email" class="form-control form-control-sm" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email">
			        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
			      </div>
			      <div class="form-group">
			        <label for="exampleInputPassword1">Password</label>
			        <input type="password" class="form-control form-control-sm" id="exampleInputPassword1" placeholder="Password" name="password">
			      </div>
			      <button type="submit" class="btn btn-primary">Submit</button>
			    </fieldset>
		    </form>
		</div>
	</div>
</div>
@endsection
