@extends('layouts.app')
@section('content')
<div class="row">
	<div class="col-lg-12">
		<div class="bs-component">
				<h5>Microcept Technologies and Education Registrations</h5>
		    <table class="table table-hover">
			  <thead>
			    <tr>
			      <th scope="col">Name</th>
			      <th scope="col">Email</th>
			      <th scope="col">Phone</th>
			      <th scope="col">Message</th>
			      <th scope="col">Date</th>
			    </tr>
			  </thead>
			  <tbody>
			  	@foreach($registrations as $registration)
			    <tr>
			      <td>{{$registration->name}}</td>
			      <td>{{$registration->email}}</td>
			      <td>{{$registration->phone}}</td>
			      <td>{{$registration->message}}</td>
			      <td>{{$registration->created_at}}</td>
			    </tr>
			    @endforeach
			  </tbody>
			</table> 
		</div>
	</div>
</div>
@endsection
