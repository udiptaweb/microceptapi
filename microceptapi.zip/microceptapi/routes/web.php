<?php

$router->get('/', function () use ($router) {
    return 'Microcept Technologis and Education API';
});
$router->get('/create/user', function () use ($router) {
    return view('admin.CreateUser');
});

$router->group(['prefix'=>'api'],function() use ($router){
	$router->get('users',['uses'=>'UserController@showAllUsers']);
	$router->get('users/{id}',['uses'=>'UserController@showOneUser']);
	$router->post('users/create',['uses'=>'UserController@createUser']);
	$router->delete('users/delete/{id}',['uses'=>'UserController@deleteOneUser']);
	$router->put('users/update/{id}',['uses'=>'UserController@updateUser']);
	//FORM
	$router->post('techonologies/registration',['uses'=>'RegistrationController@TechnoRegistration']);
	$router->get('techno/registrations',['uses'=>'RegistrationController@ViewTechnoRegistrations']);
    $router->post('microcept/sitevisit/increase',['uses'=>'SiteVisitController@increaseMicroceptVisit']);
     $router->get('sitevisit/view',['uses'=>'SiteVisitController@ViewSiteVisit']);
});

