<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-lg-12">
		<div class="bs-component">
				<h5>Microcept Technologies and Education Registrations</h5>
		    <table class="table table-hover">
			  <thead>
			    <tr>
			      <th scope="col">Name</th>
			      <th scope="col">Email</th>
			      <th scope="col">Phone</th>
			      <th scope="col">Message</th>
			      <th scope="col">Date</th>
			    </tr>
			  </thead>
			  <tbody>
			  	<?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <tr>
			      <td><?php echo e($registration->name); ?></td>
			      <td><?php echo e($registration->email); ?></td>
			      <td><?php echo e($registration->phone); ?></td>
			      <td><?php echo e($registration->message); ?></td>
			      <td><?php echo e($registration->created_at); ?></td>
			    </tr>
			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  </tbody>
			</table> 
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\lumen\cmsapi\resources\views/admin/TechnoRegistrations.blade.php ENDPATH**/ ?>