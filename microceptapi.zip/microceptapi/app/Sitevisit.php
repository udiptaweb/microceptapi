<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sitevisit extends Model 
{
    protected $fillable = [
        'domain','count'
    ];

}
