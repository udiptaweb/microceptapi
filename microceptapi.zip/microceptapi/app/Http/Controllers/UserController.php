<?php
namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
	public function showAllUsers()
	{
		return response()->json(User::all());
	}
	public function showOneUser($id)
	{
		return response()->json(User::find($id));
	}
	public function createUser(Request $request)
	{

		 $user=User::create([
		 	'name'=>$request->name,
		 	'password'=>$request->password,
		 	'email'=>$request->email,
		 	'phone'=>$request->phone
		 ]);
		return response()->json($user,201);
	}
	public function updateUser($id, Request $request)
	{
		$user = User::findOrFail($id);
		$user->update($rquest->all());
		return response()->json($user,200);
	}
	public function deleteOneUser($id)
	{
		User::findOrFail($id)->delete();
		return response()->json('Successfully Deleted',200);
	}
}