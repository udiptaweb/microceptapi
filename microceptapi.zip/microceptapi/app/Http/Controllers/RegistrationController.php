<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Registration;


class RegistrationController extends Controller
{
	public function ViewTechnoRegistrations()
	{
		$registrations = Registration::orderBy('created_at','desc')->get();
		return view('admin.TechnoRegistrations')->with('registrations',$registrations);
	}
	public function TechnoRegistration(Request $request)
	{
		
       // $this->validate([
       // 	'name'=>'required',
       // 	'phone'=>'required',
       // ]);

       try{
       	 $registration = new Registration;
       	 $registration->name = $request->input('name');
       	 $registration->email = $request->input('email');
       	 $registration->phone = $request->input('phone');
       	 $registration->message = $request->input('message');
       	 $registration->save();

       	 return response()->json(['registration'=>$registration,'message'=>'Registered'],201);
       }catch (\Exception $e){
       	 return response()->json(['message'=>'Regsitration Failed !'],409);
       }
	}
}