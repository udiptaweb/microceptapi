<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Sitevisit;


class SiteVisitController extends Controller
{
	public function ViewSiteVisit()
	{
		$sitevisits = Sitevisit::orderBy('created_at','desc')->get();
		return view('admin.SiteVisits')->with('sitevisits',$sitevisits);
	}
	public function increaseMicroceptVisit()
	{
		
       try{
       	 $sitevisit = new sitevisit;
       	 $sitevisit->domain = 'microcept.in';
       	 $sitevisit->count = 1;
       	 $sitevisit->save();
       }catch (\Exception $e){
       	
       }
	}
}